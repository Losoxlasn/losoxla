# Losoxla — Landing for WhatsApp Ads

Fichiers livrés: `index.html`, `styles.css`, `assets/` (placeholders), `README.md`.

## Déployer rapidement (iPhone via navigateur)

### Option A — GitHub Pages (projet simple)
1. Créer un compte GitHub si tu n'en as pas.
2. Sur github.com, crée un nouveau repository.
   - Si tu veux l'URL `https://<ton-username>.github.io/losoxla` crée un repo nommé `losoxla`.
   - **Remarque:** pour obtenir `losoxla.github.io` l'username GitHub doit être `losoxla` ou tu dois créer une organisation `losoxla`.
3. Dans le dépôt, clique sur "Upload files" et glisse tous les fichiers du zip (ou utilise "Add file" → "Upload files").
4. Commit.
5. Dans "Settings" → "Pages", choisis la branche `main` et le dossier `/root`, puis "Save".
6. L'URL sera `https://<ton-username>.github.io/losoxla` (ou `https://losoxla.github.io` si ton compte/org s'appelle `losoxla`).

### Option B — Netlify (drag & drop)
1. Ouvre https://app.netlify.com/drop depuis ton iPhone.
2. Dépose le contenu du zip (dézippe si nécessaire avec l'app Fichiers).
3. Netlify publiera une URL `*.netlify.app`.

### Remarques
- Les images dans `assets/` sont des placeholders. Remplace-les par tes visuels avant de lancer la campagne.
- Les boutons redirigent vers WhatsApp: `https://wa.me/221703425454`.
- Pour connecter un domaine personnalisé (gratuit via Freenom) suis la doc Netlify/GitHub Pages pour config CNAME.

Contact: WhatsApp +221703425454 — Email losxlacorp@gmail.com
